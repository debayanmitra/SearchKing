﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SearchKing
{
    public partial class searchKingMain : Form
    {
        String searchPath;
        String searchText;
        //String extensionFile;
        string pathLog = "";
        string pathLogTemp = "";
        string pathLogLine = "";
        string pathLogError = "";
        string pathProgress = "";
        string PathCollate;
        string pathCollateBackUp;
        string collateTextBox;
        string logTextBox;
        bool isFirstSearch = true;
        //bool isLogPresent = false;

        int ProgressResult = 0;
        int progressFileCount = 0;
        int progressDirCount = 0;

        public searchKingMain()
        {
            InitializeComponent();
        }

        private void cmdSearch_Click(object sender, EventArgs e)
        {
            //CHECK IF SEARCHING FOR FIRST TIME
            if (isFirstSearch == true)
            {

                if (cbCreateLog.Checked == true || cbCollateFiles.Checked == true)
                {
                    MessageBox.Show("Please remember to delete all log files after you are done with them. Keep the storage free of junk.", "Save Storage !!! Save Money", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                }

                collateTextBox = txtCollatePath.Text.ToString();
                logTextBox = txtLogPath.Text.ToString();

                isFirstSearch = false;
            }
            else
            {
                //Reset all value in the progress matrix
                lblProgressFinished.Text = "0";
                lblProgressResult.Text = "0";
                lblProgressFinishedDir.Text = "0";

                ProgressResult = 0;
                progressFileCount = 0;
                progressDirCount = 0;

                if (collateTextBox != "")
                {
                    txtCollatePath.Text = collateTextBox;
                }

                if (logTextBox != "")
                {
                    txtLogPath.Text = logTextBox;
                }
            }

            if (txtSearchPath.Text == "" || txtSearchText.Text == "")
            {
                MessageBox.Show("Search Criteria can not be blank", "Missing Search Criterias", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            if (cbCollateFiles.Checked == true && txtCollatePath.Text == "")
            {
                MessageBox.Show("Collation path can not be blank", "Missing Collate Path", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            if ( cbCreateLog.Checked == true && txtLogPath.Text == "")
            {
                MessageBox.Show("Log location can not be blank", "Missing Log location", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            stopClick();

            searchPath = txtSearchPath.Text.Trim();
            searchText = txtSearchText.Text.Trim();

            int folderNotFoundFlag = 0;

            DialogResult folderNotFoundUser;

            readyLogCollation();
            
            int flag=0;

            String searchPathBegin = searchPath;

            pathCollateBackUp = PathCollate;

            if (chkFolderRange.Checked != true) //if user does not want to check within a folder range, only inside a folder which has documents in it
            {               
                if (searchText.Length > 0)
                {

                    if (!System.IO.Directory.Exists(searchPath))
                    {
                        MessageBox.Show("Specified search location not found", "Wrong Location", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        startClick();
                        return;
                        
                    }
                    
                    if (System.IO.Directory.Exists(searchPath) && rbSearchWithinFile.Checked == true) //*** search inside a file 
                    {

                        folderNotFoundFlag = 0;

                        if (searchText.Length > 0)
                        {
                            searchInFileDir(searchPath, searchText);
                        }
                        else
                        {
                            MessageBox.Show("Please mention what to search.", "Wrong Input", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }

                    if (System.IO.Directory.Exists(searchPath) && rbSearchInFileName.Checked == true) //*** searching in file name
                    {

                        //progressDirCount++;
                        folderNotFoundFlag = 0;

                        if (searchText.Length > 0)
                        {
                            searchFileName(searchPath, searchText);
                        }
                        else
                        {
                            MessageBox.Show("Please mention what to search.", "Wrong Input", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Please mention what to search.", "Wrong Input", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else //if user want to check within a folder range, only inside a folder which has documents in it
            {
                int rangeStart = 0;
                Int32.TryParse(txtFolderRangeStart.Text, out rangeStart);
                int rangeEnd = 0;
                Int32.TryParse(txtFolderRangeEnd.Text, out rangeEnd);

                try
                {
                    if (rangeStart < rangeEnd && rangeStart != 0)
                    {
                        for (flag = rangeStart; flag <= rangeEnd; flag++)
                        {
                            if (searchPath.EndsWith("\\"))
                                searchPath = searchPath + flag.ToString();
                            else
                                searchPath = searchPath + "\\" + flag.ToString();

                            if (!System.IO.Directory.Exists(searchPath))
                            {
                                folderNotFoundFlag++;

                                //Log the folder which is not availble
                                System.IO.File.AppendAllText(pathLogError, "Folder not found " + searchPath + Environment.NewLine);

                                if (folderNotFoundFlag == 10)
                                {
                                    folderNotFoundUser = MessageBox.Show("Already 10 consecutive folders are not present.. Do you want to waste more time?", "Many Missing folders", MessageBoxButtons.OKCancel, MessageBoxIcon.Error);
                                    if (folderNotFoundUser == DialogResult.OK)
                                    {
                                        folderNotFoundFlag = 0;
                                    }
                                    else
                                    {
                                        folderNotFoundFlag = 0;
                                        break;
                                    }
                                }
                            }
                            else if (System.IO.Directory.Exists(searchPath) && rbSearchWithinFile.Checked == true) //*** search inside a file 
                            {

                                progressDirCount++;
                                folderNotFoundFlag = 0;

                                if (searchText.Length > 0)
                                {
                                    searchInFileDir(searchPath, searchText);
                                }
                                else
                                {
                                    MessageBox.Show("Please mention what to search.", "Wrong Input", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                }
                            }

                            else if (System.IO.Directory.Exists(searchPath) && rbSearchInFileName.Checked == true) //*** searching in file name
                            {

                                progressDirCount++;
                                folderNotFoundFlag = 0;

                                if (searchText.Length > 0)
                                {
                                    searchFileName(searchPath, searchText);
                                }
                                else
                                {
                                    MessageBox.Show("Please mention what to search.", "Wrong Input", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                }
                            }
                            else
                            {
                                MessageBox.Show("Invalid path selected.", "Wrong Input", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                            searchPath = searchPathBegin;
                            lblProgressFinished.Text = flag.ToString();
                        }
                    }

                    // IF BOTH RANGES ARE EQUAL AND NON ZERO

                    else if (rangeStart == rangeEnd && rangeStart != 0)
                    {
                        if (searchPath.EndsWith("\\"))
                            searchPath = searchPath + rangeStart.ToString();
                        else
                            searchPath = searchPath + "\\" + rangeStart.ToString();

                        if (System.IO.Directory.Exists(searchPath) && rbSearchWithinFile.Checked == true) //*** search inside a file 
                        {
                            progressDirCount++;

                            if (searchText.Length > 0)
                            {
                                searchInFileDir(searchPath, searchText);
                            }
                            else
                            {
                                MessageBox.Show("Please mention what to search.", "Wrong Input", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                        }

                        else if (System.IO.Directory.Exists(searchPath) && rbSearchInFileName.Checked == true) //*** searching in file name
                        {
                            progressDirCount++;

                            if (searchText.Length > 0)
                            {
                                searchFileName(searchPath, searchText);
                            }
                            else
                            {
                                MessageBox.Show("Please mention what to search.", "Wrong Input", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                        }

                        else
                        {
                            MessageBox.Show("Invalid path selected.", "Wrong Input", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }

                    //IF RANGE END IS GREATER THAN START OR RANGE STARTS FROM ZERO   rangeEnd < rangeStart

                    else if (rangeStart == 0)
                    {
                        MessageBox.Show("No realistic folder value has been passed!!", "Wrong Input", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }

                    // IF NO RANGE END HAS BEEN PROVIDED... RANGE START + 2000 WILL BE SEARCHED

                    else if (rangeEnd == 0 && rangeStart > 0)
                    {
                        MessageBox.Show("End value not supplied, Search will be performed on Start Number + 1000 numeric folders.", "Limited Input", MessageBoxButtons.OK, MessageBoxIcon.Information);

                        for (flag = rangeStart; flag <= (rangeStart + 1000); flag++)
                        {
                            if (searchPath.EndsWith("\\"))
                                searchPath = searchPath + flag.ToString();
                            else
                                searchPath = searchPath + "\\" + flag.ToString();

                            if (!System.IO.Directory.Exists(searchPath))
                            {
                                folderNotFoundFlag++;

                                //Log the folder which is not availble
                                System.IO.File.AppendAllText(pathLogError, "Folder not found " + searchPath + Environment.NewLine);

                                if (folderNotFoundFlag == 10)
                                {
                                    folderNotFoundUser = MessageBox.Show("Already 10 consecutive folders are not present.. Do you want to waste more time?", "Too many missing folders", MessageBoxButtons.OKCancel, MessageBoxIcon.Error);
                                    if (folderNotFoundUser == DialogResult.OK)
                                    {
                                        folderNotFoundFlag = 0;
                                    }
                                    else
                                    {
                                        folderNotFoundFlag = 0;
                                        break;
                                    }
                                }
                            }
                            else if (System.IO.Directory.Exists(searchPath) && rbSearchWithinFile.Checked == true) //*** search inside a file 
                            {

                                progressDirCount++;
                                folderNotFoundFlag = 0;

                                if (searchText.Length > 0)
                                {
                                    searchInFileDir(searchPath, searchText); 
                                }
                                else
                                {
                                    MessageBox.Show("Please mention what to search.", "Wrong Input", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                }
                            }

                            else if (System.IO.Directory.Exists(searchPath) && rbSearchInFileName.Checked == true) //*** searching in file name
                            {

                                progressDirCount++;
                                folderNotFoundFlag = 0;

                                if (searchText.Length > 0)
                                {
                                    searchFileName(searchPath, searchText);
                                   
                                }
                                else
                                {
                                    MessageBox.Show("Please mention what to search.", "Wrong Input", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                }
                            }
                            else
                            {
                                MessageBox.Show("Invalid path selected.", "Wrong Input", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }

                            searchPath = searchPathBegin;
                            lblProgressFinished.Text = flag.ToString();
                        }
                    }
                    else
                        MessageBox.Show("Folder Range Start value can not be less than End value", "Wrong Input", MessageBoxButtons.OK, MessageBoxIcon.Error);

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "May Day !!! May Day!!!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }

            startClick();

            if (cbCreateLog.Checked == true || cbCollateFiles.Checked == true)
            {
                cmdOpenLogFolder.Visible = true;
            }
            else
            {
                cmdOpenLogFolder.Visible = false;
            }

            panelProgress.Visible = true;            

            lblProgressResult.Text = ProgressResult.ToString();
            lblProgressFinished.Text = progressFileCount.ToString();

            //if (chkFolderRange.Checked == true)
            //{
                lblProgressFinishedDir.Text = progressDirCount.ToString();
            //}
            //else
            //{
                //lblProgressFinishedDir.Text = (progressDirCount - 1).ToString();
            //}

        }

        public void searchInFileDir(string strPath, string sText) 
        {
            //string cbExtenstion = cbExtentions.Text;
            string cbExtenstion = txtExtension.Text;
            cbExtenstion = cbExtenstion.Trim();
            cbExtenstion = cbExtenstion.Replace(".",string.Empty);
            
            List<string> listSuccessFilePath = new List<string>();
            List<string> listSuccessFileText = new List<string>();

           // var searchResultLine = null;

            try
            {        
                //ADD CODE FOR CHECKIGN THE DROP DOWN VALUE TO BE EQUAL TO "----SELECT-------"
                //if (cbExtenstion == "-----Select-----")
                if (cbExtenstion == "")
                {
                    MessageBox.Show("Please select which type (extensions) of file to be searched", "Type of file not selected", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }
                else //if (cbExtenstion) 
                {
                    List<string> allFolders = new List<string>(Directory.EnumerateDirectories(strPath, "*",SearchOption.AllDirectories));

                    if (allFolders.Any()) //If has folders and sub folders
                    {
                        Parallel.ForEach(allFolders, (eachFolder) =>
                        {
                            //increase the count of directory searched
                            progressDirCount++;

                            List<string> allFiles = new List<string>(Directory.EnumerateFiles(eachFolder, "*." + cbExtenstion));

                            if (allFiles.Any())
                            {
                                RegexOptions reOption;
                                Regex sRegex;

                                if (chkIgnoreCase.Checked == true)
                                {
                                    reOption = RegexOptions.IgnoreCase;
                                    sRegex = new Regex(sText, reOption);
                                }
                                else
                                {
                                    //reOption = RegexOptions.IgnoreCase;
                                    sRegex = new Regex(sText);
                                }

                                //IF SEARCH STRING IS ARRAY
                                //Regex[] reResult = sText.Select(LookupString => new Regex(String.Format(@"{0}", Regex.Escape(sText)), reOption)).ToArray();

                                //var searchResult = "";

                                Parallel.ForEach(allFiles, (eachFile) =>
                                {
                                    progressFileCount++;



                                    var searchResultFiles = (from matchedLine in File.ReadLines(eachFile)
                                                        where sRegex.IsMatch(matchedLine)
                                                        select eachFile).ToList();

                                    var searchResultLines = (from matchedLine in File.ReadLines(eachFile)
                                                        where sRegex.IsMatch(matchedLine)
                                                        select matchedLine).ToList();

                                    //IF SEARCH IS SUCCESSFUL
                                    if (searchResultFiles.Any())
                                    {
                                        ProgressResult++;
                                        listSuccessFilePath.Add(eachFile);
                                    }

                                    if (searchResultLines.Any())
                                    {
                                        //ProgressResult++;

                                        foreach (string searchedLine in searchResultLines)
                                        {
                                            listSuccessFileText.Add(searchedLine);
                                        }
                                    }
                                });
                            }
                        });
                    }
                    else //If does not have folders and sub folders ONLY FILES
                    {
                        List<string> allFiles = new List<string>(Directory.EnumerateFiles(strPath, "*." + cbExtenstion));

                        if (allFiles.Any())
                        {
                            RegexOptions reOption;
                            Regex sRegex;

                            if (chkIgnoreCase.Checked == true)
                            {
                                reOption = RegexOptions.IgnoreCase;
                                sRegex = new Regex(sText, reOption);
                            }
                            else
                            {
                                //reOption = RegexOptions.IgnoreCase;
                                sRegex = new Regex(sText);
                            }

                            //IF SEARCH STRING IS ARRAY
                            //Regex[] reResult = sText.Select(LookupString => new Regex(String.Format(@"{0}", Regex.Escape(sText)), reOption)).ToArray();

                            //var searchResult = "";

                            Parallel.ForEach(allFiles, (eachFile) =>
                            {
                                progressFileCount++;                              

                                if (progressFileCount % 100 == 0)
                                {
                                    System.IO.File.AppendAllText(pathProgress, "Search is complete within " + progressFileCount + " Files." + Environment.NewLine);
                                }

                                var searchResult = (from matchedLine in File.ReadLines(eachFile)
                                                    where sRegex.IsMatch(matchedLine)
                                                    select eachFile).ToList();
                                
                                var searchResultLines = (from matchedLine in File.ReadLines(eachFile)
                                                         where sRegex.IsMatch(matchedLine)
                                                         select matchedLine).ToList();

                                //IF SEARCH IS SUCCESSFUL
                                if (searchResult.Any())
                                {
                                    ProgressResult++;
                                    listSuccessFilePath.Add(eachFile);
                                }

                                if (searchResultLines.Any())
                                {

                                    foreach (string searchedLine in searchResultLines)
                                    {
                                        listSuccessFileText.Add(searchedLine);
                                    }
                                }
                            });
                        }
                    }

                    if (listSuccessFilePath.Any())
                    {
                        foreach (string eachSuccessFilePath in listSuccessFilePath)
                        {
                            try
                            {
                                //collate Files;
                                if (cbCollateFiles.Checked == true)
                                {
                                    PathCollate = pathCollateBackUp + eachSuccessFilePath.ToString().Substring(eachSuccessFilePath.ToString().LastIndexOf('\\'));
                                    System.IO.File.Copy(eachSuccessFilePath.ToString(), PathCollate, true);

                                    txtCollatePath.Text = pathCollateBackUp;
                                }

                                //create logs;
                                if (cbCreateLog.Checked == true)
                                {
                                
                                    //IF LOG FILE EXISTS
                                    if (File.Exists(pathLog))
                                    {
                                        if (new FileInfo(pathLog).Length == 0)
                                        {
                                            System.IO.File.AppendAllText(pathLog, eachSuccessFilePath.ToString() + Environment.NewLine);
                                        }
                                        else
                                        {
                                            if (!File.ReadAllLines(pathLog).Contains(eachSuccessFilePath.ToString()))
                                            {
                                                System.IO.File.AppendAllText(pathLog, eachSuccessFilePath.ToString() + Environment.NewLine); 
                                            }
                                        }
                                    }

                                    txtLogPath.Text = pathLog;
                                }
                            }
                            catch
                            {
                                MessageBox.Show("Error while writing the Log file.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                        }

                        //iterate the list of lines where the text was found

                        foreach (string eachSuccessFileText in listSuccessFileText)
                        {
                            try
                            {
                                //create logs;
                                if (cbCreateLog.Checked == true)
                                {
                                    //IF LOG FILE EXISTS
                                    if (File.Exists(pathLogLine))
                                    {
                                        if (new FileInfo(pathLogLine).Length == 0)
                                        {
                                            System.IO.File.AppendAllText(pathLogLine, eachSuccessFileText.ToString() + Environment.NewLine);
                                        }
                                        else
                                        {
                                            if (!File.ReadAllLines(pathLogLine).Contains(eachSuccessFileText.ToString()))
                                            {
                                                System.IO.File.AppendAllText(pathLogLine, eachSuccessFileText.ToString() + Environment.NewLine);
                                            }
                                        }
                                    }

                                    //txtLogPath.Text = pathLog;
                                }
                            }
                            catch
                            {
                                MessageBox.Show("Error while writing the Log file.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                        }

                    }
                }
            }
            catch (System.Exception e)
            {
                MessageBox.Show(e.Message, "Search incomplete.",MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }
              
        public void searchFileName(string strPath, string serText) //Searching within a File Name only
        {
            //string[] files = Directory.GetFiles(strPath,serText,System.IO.SearchOption.AllDirectories);
            string[] files = Directory.GetFiles(strPath);
            //string fileName = "";

            string cbExtenstion = txtExtension.Text;
            cbExtenstion = cbExtenstion.Trim();
            cbExtenstion = cbExtenstion.Replace(".", string.Empty);

            //VENISH BABA KA CHANGE STARTS HERE  

            List<string> listSuccessFilePath = new List<string>();

            //GET LIST OF ALL FOLDERS PRESENT IN A DIRECTORY
            List<string> allFolders = new List<string>(Directory.EnumerateDirectories(strPath, "*", SearchOption.AllDirectories));

            //GET LIST OF ALL FILES PRESENT IN A DIRECTORY
            List<string> allFiles = new List<string>(Directory.GetFiles(strPath, "*." + cbExtenstion, SearchOption.AllDirectories));

            progressDirCount = allFolders.Count();
            progressFileCount = allFiles.Count();

            if (allFiles.Any())
            {
                RegexOptions reOption;
                Regex sRegex;

                if (chkIgnoreCase.Checked == true)
                {
                    reOption = RegexOptions.IgnoreCase;
                    sRegex = new Regex(serText, reOption);
                }
                else
                {
                    sRegex = new Regex(serText);
                }               

                
                if (pathProgress != "")
                {
                    System.IO.File.AppendAllText(pathProgress, "Search is in progress for " + allFiles.Count() + " Files." + Environment.NewLine);
                }
                

                var searchResult = from file in allFiles
                                    where sRegex.IsMatch(file)
                                    select file;

                //IF FOUND
                if (searchResult.Any())
                {
                    foreach (string eachSuccessFilePath in searchResult)
                    {
                        ProgressResult++;                        

                        try
                        {
                            //collate Files;
                            if (cbCollateFiles.Checked == true)
                            {
                                PathCollate = pathCollateBackUp + eachSuccessFilePath.ToString().Substring(eachSuccessFilePath.ToString().LastIndexOf('\\'));
                                System.IO.File.Copy(eachSuccessFilePath.ToString(), PathCollate, true);

                                txtCollatePath.Text = pathCollateBackUp;
                            }

                            //create logs;
                            if (cbCreateLog.Checked == true)
                            {

                                //IF LOG FILE EXISTS
                                if (File.Exists(pathLog))
                                {
                                    if (new FileInfo(pathLog).Length == 0)
                                    {
                                        System.IO.File.AppendAllText(pathLog, eachSuccessFilePath.ToString() + Environment.NewLine);

                                        //IF COLLATE FILES CHECKED
                                        if (cbCollateFiles.Checked == true)
                                        {
                                            PathCollate = pathCollateBackUp + eachSuccessFilePath.ToString().Substring(eachSuccessFilePath.ToString().LastIndexOf('\\'));
                                            System.IO.File.Copy(eachSuccessFilePath.ToString(), PathCollate, true);
                                        }
                                    }
                                    else
                                    {
                                        if (!File.ReadAllLines(pathLog).Contains(eachSuccessFilePath.ToString()))
                                        {
                                            System.IO.File.AppendAllText(pathLog, eachSuccessFilePath.ToString() + Environment.NewLine);
                                        }
                                    }
                                }

                                txtLogPath.Text = pathLog;
                            }
                        }
                        catch
                        {
                            MessageBox.Show("Error while writing the Log file.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }

             }
        }

        private void cmdBrowse_Click(object sender, EventArgs e)
        {
            DialogResult result = dlgFolder.ShowDialog();
            if (result == DialogResult.OK)
            {
                txtSearchPath.Text = dlgFolder.SelectedPath;
            }
        }

        private void cmdClear_Click(object sender, EventArgs e)
        {
            txtSearchPath.Text = "";
            txtSearchText.Text = "";
            txtLogPath.Text = ""; 
            txtFolderRangeStart.Text = "";
            txtFolderRangeEnd.Text = "";
            panelProgress.Visible = false;
            txtCollatePath.Text = "";

            lblProgressFinished.Text = "0";
            lblProgressResult.Text = "0";

        }

        private void cmdClose_Click(object sender, EventArgs e)
        {
            MessageBox.Show("If you have gathered log files, please remember to delete all of them after you are done with them. Keep the storage free of junk.", "Save Storage !!! Save Money", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
            
            this.Close();
        }

        
        
        private void lblHelp_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            MessageBox.Show("SearchKing v5.0" + System.Environment.NewLine + "----------------------------------" + System.Environment.NewLine + "Thank You for using SearchKing." + System.Environment.NewLine + System.Environment.NewLine + "For any query please reach out to Debayan. Call below helpline number." + System.Environment.NewLine + System.Environment.NewLine + "+1 608.471.3833", "SearchKing v5.0 - Help", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }


        public void stopClick()
        {
            cmdBrowse.Enabled = false;
            cmdSearch.Enabled = false;
            cmdClear.Enabled = false;
            cmdClose.Enabled = false;
            txtSearchPath.Enabled = false;
            txtSearchText.Enabled = false;
            txtLogPath.Enabled = false;
            txtCollatePath.Enabled = false;
        }

        public void startClick()
        {
            cmdBrowse.Enabled = true;
            cmdSearch.Enabled = true;
            cmdClear.Enabled = true;
            cmdClose.Enabled = true;
            txtSearchPath.Enabled = true;
            txtSearchText.Enabled = true;
            txtLogPath.Enabled = true;
            txtCollatePath.Enabled = true;
        }

        public void readyLogCollation()
        {
            DateTime now = DateTime.Now;
            //string nowString = now.ToString("dd MMMM yyyy hh:mm:ss tt"); //01 May 2019 04:35:48 PM
            string nowString = now.ToString("MMddyyyyHHmmss"); //01 May 2019 04:35:48 PM

            pathLogTemp = txtLogPath.Text;

            if (System.IO.Directory.Exists(pathLogTemp) == false)
            {
                System.IO.Directory.CreateDirectory(pathLogTemp);
            }


            //CREATE ERROR LOG FILE
            if (rbSearchInFileName.Checked == true)
            {
                pathLogError = pathLogTemp + "\\SearchInFileName-Error-" + nowString + ".log";
                System.IO.File.CreateText(pathLogError).Close();
            }

            if (rbSearchWithinFile.Checked == true)
            {
                pathLogError = pathLogTemp + "\\SearchWithinFile-Error-" + nowString + ".log";
                System.IO.File.CreateText(pathLogError).Close();
            }

            //CREATE PROGRESS AND COMMON LOG FILE
            if (cbCreateLog.Checked == true)
            {
                if (rbSearchInFileName.Checked == true)
                {
                    //Create progress Log file
                    pathProgress = pathLogTemp + "\\SearchInFileName-Progress-" + nowString + ".txt";
                    System.IO.File.CreateText(pathProgress).Close();

                    pathLog = pathLogTemp + "\\SearchInFileName-" + nowString + ".txt";
                    System.IO.File.CreateText(pathLog).Close();

                    pathLogLine = pathLogTemp + "\\SearchInFileName-Line-" + nowString + ".txt";
                    System.IO.File.CreateText(pathLogLine).Close();
                }

                if (rbSearchWithinFile.Checked == true)
                {
                    //Create progress Log file
                    pathProgress = pathLogTemp + "\\SearchWithinFile-Progress-" + nowString + ".txt";
                    System.IO.File.CreateText(pathProgress).Close();

                    pathLog = pathLogTemp + "\\SearchWithinFile-" + nowString + ".txt";
                    System.IO.File.CreateText(pathLog).Close();

                    pathLogLine = pathLogTemp + "\\SearchWithinFile-Line-" + nowString + ".txt";
                    System.IO.File.CreateText(pathLogLine).Close();
                }
            }

            //CREATE COLLATION FOLDER
            if (cbCollateFiles.Checked == true)
            {
                PathCollate = txtCollatePath.Text + "\\CollatedFiles-" + nowString;
                System.IO.Directory.CreateDirectory(PathCollate);
            }
        }

        private void chkFolderRange_CheckedChanged(object sender, EventArgs e)
        {
            if (chkFolderRange.Checked == true)
            {
                txtFolderRangeStart.Enabled = true;
                txtFolderRangeEnd.Enabled = true;
            }
            if (chkFolderRange.Checked == false)
            {
                txtFolderRangeStart.Enabled = false;
                txtFolderRangeEnd.Enabled = false;
            }
        }

        private void cmdOpenLogFolder_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Please remember to delete all log files after you are done with them. Keep the storage free of junk.", "Save Storage !!! Save Money", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);

            if (pathLogTemp != "")
            {
                System.Diagnostics.Process.Start(pathLogTemp);
            }
        }

     }
}


