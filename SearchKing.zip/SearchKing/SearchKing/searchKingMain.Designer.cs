﻿namespace SearchKing
{
    partial class searchKingMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(searchKingMain));
            this.txtSearchPath = new System.Windows.Forms.TextBox();
            this.cmdSearch = new System.Windows.Forms.Button();
            this.txtSearchText = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.cmdBrowse = new System.Windows.Forms.Button();
            this.cmdClear = new System.Windows.Forms.Button();
            this.cmdClose = new System.Windows.Forms.Button();
            this.dlgFolder = new System.Windows.Forms.FolderBrowserDialog();
            this.label5 = new System.Windows.Forms.Label();
            this.lblHelp = new System.Windows.Forms.LinkLabel();
            this.treeList = new System.Windows.Forms.TreeView();
            this.txtLogPath = new System.Windows.Forms.TextBox();
            this.cbCreateLog = new System.Windows.Forms.CheckBox();
            this.cbCollateFiles = new System.Windows.Forms.CheckBox();
            this.txtCollatePath = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.panelProgress = new System.Windows.Forms.Panel();
            this.cmdOpenLogFolder = new System.Windows.Forms.Button();
            this.lblProgressFinishedDir = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.lblProgressResult = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.lblProgressFinished = new System.Windows.Forms.Label();
            this.chkIgnoreCase = new System.Windows.Forms.CheckBox();
            this.label7 = new System.Windows.Forms.Label();
            this.rbSearchWithinFile = new System.Windows.Forms.RadioButton();
            this.rbSearchInFileName = new System.Windows.Forms.RadioButton();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.txtFolderRangeStart = new System.Windows.Forms.NumericUpDown();
            this.txtFolderRangeEnd = new System.Windows.Forms.NumericUpDown();
            this.chkFolderRange = new System.Windows.Forms.CheckBox();
            this.panelInput = new System.Windows.Forms.Panel();
            this.label8 = new System.Windows.Forms.Label();
            this.txtExtension = new System.Windows.Forms.TextBox();
            this.panelProgress.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtFolderRangeStart)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtFolderRangeEnd)).BeginInit();
            this.panelInput.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtSearchPath
            // 
            this.txtSearchPath.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSearchPath.Location = new System.Drawing.Point(168, 74);
            this.txtSearchPath.Name = "txtSearchPath";
            this.txtSearchPath.Size = new System.Drawing.Size(303, 22);
            this.txtSearchPath.TabIndex = 0;
            // 
            // cmdSearch
            // 
            this.cmdSearch.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmdSearch.Location = new System.Drawing.Point(154, 418);
            this.cmdSearch.Name = "cmdSearch";
            this.cmdSearch.Size = new System.Drawing.Size(317, 43);
            this.cmdSearch.TabIndex = 2;
            this.cmdSearch.Text = "Search";
            this.cmdSearch.UseVisualStyleBackColor = true;
            this.cmdSearch.Click += new System.EventHandler(this.cmdSearch_Click);
            // 
            // txtSearchText
            // 
            this.txtSearchText.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSearchText.Location = new System.Drawing.Point(198, 292);
            this.txtSearchText.Name = "txtSearchText";
            this.txtSearchText.Size = new System.Drawing.Size(261, 24);
            this.txtSearchText.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(27, 75);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(137, 18);
            this.label1.TabIndex = 4;
            this.label1.Text = "Location to Search:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(27, 293);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(108, 18);
            this.label2.TabIndex = 5;
            this.label2.Text = "Text to Search:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(27, 52);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(0, 18);
            this.label3.TabIndex = 6;
            // 
            // cmdBrowse
            // 
            this.cmdBrowse.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmdBrowse.Location = new System.Drawing.Point(477, 69);
            this.cmdBrowse.Name = "cmdBrowse";
            this.cmdBrowse.Size = new System.Drawing.Size(118, 32);
            this.cmdBrowse.TabIndex = 3;
            this.cmdBrowse.Text = "Browse";
            this.cmdBrowse.UseVisualStyleBackColor = true;
            this.cmdBrowse.Click += new System.EventHandler(this.cmdBrowse_Click);
            // 
            // cmdClear
            // 
            this.cmdClear.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmdClear.Location = new System.Drawing.Point(30, 418);
            this.cmdClear.Name = "cmdClear";
            this.cmdClear.Size = new System.Drawing.Size(118, 43);
            this.cmdClear.TabIndex = 4;
            this.cmdClear.Text = "Clear All";
            this.cmdClear.UseVisualStyleBackColor = true;
            this.cmdClear.Click += new System.EventHandler(this.cmdClear_Click);
            // 
            // cmdClose
            // 
            this.cmdClose.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmdClose.Location = new System.Drawing.Point(477, 418);
            this.cmdClose.Name = "cmdClose";
            this.cmdClose.Size = new System.Drawing.Size(118, 43);
            this.cmdClose.TabIndex = 5;
            this.cmdClose.Text = "Close";
            this.cmdClose.UseVisualStyleBackColor = true;
            this.cmdClose.Click += new System.EventHandler(this.cmdClose_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Cooper Black", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(24, 20);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(172, 31);
            this.label5.TabIndex = 13;
            this.label5.Text = "SearchKing";
            // 
            // lblHelp
            // 
            this.lblHelp.AutoSize = true;
            this.lblHelp.BackColor = System.Drawing.SystemColors.Control;
            this.lblHelp.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHelp.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.lblHelp.LinkColor = System.Drawing.Color.OrangeRed;
            this.lblHelp.Location = new System.Drawing.Point(534, 29);
            this.lblHelp.Name = "lblHelp";
            this.lblHelp.Size = new System.Drawing.Size(61, 20);
            this.lblHelp.TabIndex = 15;
            this.lblHelp.TabStop = true;
            this.lblHelp.Text = "Help!!!";
            this.lblHelp.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lblHelp_LinkClicked);
            // 
            // treeList
            // 
            this.treeList.Location = new System.Drawing.Point(713, 189);
            this.treeList.Name = "treeList";
            this.treeList.Size = new System.Drawing.Size(316, 173);
            this.treeList.TabIndex = 16;
            // 
            // txtLogPath
            // 
            this.txtLogPath.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLogPath.Location = new System.Drawing.Point(198, 330);
            this.txtLogPath.Name = "txtLogPath";
            this.txtLogPath.Size = new System.Drawing.Size(397, 24);
            this.txtLogPath.TabIndex = 37;
            this.txtLogPath.Text = "c:\\SearchKingLog";
            // 
            // cbCreateLog
            // 
            this.cbCreateLog.AutoSize = true;
            this.cbCreateLog.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbCreateLog.Location = new System.Drawing.Point(30, 330);
            this.cbCreateLog.Name = "cbCreateLog";
            this.cbCreateLog.Size = new System.Drawing.Size(141, 22);
            this.cbCreateLog.TabIndex = 46;
            this.cbCreateLog.Text = "Create Log here :";
            this.cbCreateLog.UseVisualStyleBackColor = true;
            // 
            // cbCollateFiles
            // 
            this.cbCollateFiles.AutoSize = true;
            this.cbCollateFiles.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbCollateFiles.Location = new System.Drawing.Point(30, 369);
            this.cbCollateFiles.Name = "cbCollateFiles";
            this.cbCollateFiles.Size = new System.Drawing.Size(162, 22);
            this.cbCollateFiles.TabIndex = 47;
            this.cbCollateFiles.Text = "Collate all files here :";
            this.cbCollateFiles.UseVisualStyleBackColor = true;
            // 
            // txtCollatePath
            // 
            this.txtCollatePath.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCollatePath.Location = new System.Drawing.Point(198, 369);
            this.txtCollatePath.Name = "txtCollatePath";
            this.txtCollatePath.Size = new System.Drawing.Size(397, 24);
            this.txtCollatePath.TabIndex = 48;
            this.txtCollatePath.Text = "c:\\SearchKingLog";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(8, 13);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(124, 18);
            this.label4.TabIndex = 49;
            this.label4.Text = "Searched in files: ";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panelProgress
            // 
            this.panelProgress.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelProgress.Controls.Add(this.cmdOpenLogFolder);
            this.panelProgress.Controls.Add(this.lblProgressFinishedDir);
            this.panelProgress.Controls.Add(this.label6);
            this.panelProgress.Controls.Add(this.lblProgressResult);
            this.panelProgress.Controls.Add(this.label11);
            this.panelProgress.Controls.Add(this.lblProgressFinished);
            this.panelProgress.Controls.Add(this.label4);
            this.panelProgress.Location = new System.Drawing.Point(30, 488);
            this.panelProgress.Name = "panelProgress";
            this.panelProgress.Size = new System.Drawing.Size(565, 83);
            this.panelProgress.TabIndex = 51;
            this.panelProgress.Visible = false;
            // 
            // cmdOpenLogFolder
            // 
            this.cmdOpenLogFolder.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.cmdOpenLogFolder.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.cmdOpenLogFolder.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmdOpenLogFolder.Location = new System.Drawing.Point(300, 47);
            this.cmdOpenLogFolder.Name = "cmdOpenLogFolder";
            this.cmdOpenLogFolder.Size = new System.Drawing.Size(128, 24);
            this.cmdOpenLogFolder.TabIndex = 52;
            this.cmdOpenLogFolder.Text = "Open Log Folder";
            this.cmdOpenLogFolder.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.cmdOpenLogFolder.UseVisualStyleBackColor = true;
            this.cmdOpenLogFolder.Visible = false;
            this.cmdOpenLogFolder.Click += new System.EventHandler(this.cmdOpenLogFolder_Click);
            // 
            // lblProgressFinishedDir
            // 
            this.lblProgressFinishedDir.AutoSize = true;
            this.lblProgressFinishedDir.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProgressFinishedDir.ForeColor = System.Drawing.Color.Red;
            this.lblProgressFinishedDir.Location = new System.Drawing.Point(435, 14);
            this.lblProgressFinishedDir.Name = "lblProgressFinishedDir";
            this.lblProgressFinishedDir.Size = new System.Drawing.Size(16, 18);
            this.lblProgressFinishedDir.TabIndex = 56;
            this.lblProgressFinishedDir.Text = "0";
            this.lblProgressFinishedDir.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(297, 13);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(143, 18);
            this.label6.TabIndex = 55;
            this.label6.Text = "Searched in folders: ";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblProgressResult
            // 
            this.lblProgressResult.AutoSize = true;
            this.lblProgressResult.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProgressResult.ForeColor = System.Drawing.Color.Red;
            this.lblProgressResult.Location = new System.Drawing.Point(130, 47);
            this.lblProgressResult.Name = "lblProgressResult";
            this.lblProgressResult.Size = new System.Drawing.Size(16, 18);
            this.lblProgressResult.TabIndex = 54;
            this.lblProgressResult.Text = "0";
            this.lblProgressResult.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.Black;
            this.label11.Location = new System.Drawing.Point(8, 47);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(130, 18);
            this.label11.TabIndex = 53;
            this.label11.Text = "Text found in files: ";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblProgressFinished
            // 
            this.lblProgressFinished.AutoSize = true;
            this.lblProgressFinished.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProgressFinished.ForeColor = System.Drawing.Color.Red;
            this.lblProgressFinished.Location = new System.Drawing.Point(126, 13);
            this.lblProgressFinished.Name = "lblProgressFinished";
            this.lblProgressFinished.Size = new System.Drawing.Size(16, 18);
            this.lblProgressFinished.TabIndex = 51;
            this.lblProgressFinished.Text = "0";
            this.lblProgressFinished.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // chkIgnoreCase
            // 
            this.chkIgnoreCase.AutoSize = true;
            this.chkIgnoreCase.Checked = true;
            this.chkIgnoreCase.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkIgnoreCase.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkIgnoreCase.Location = new System.Drawing.Point(488, 292);
            this.chkIgnoreCase.Name = "chkIgnoreCase";
            this.chkIgnoreCase.Size = new System.Drawing.Size(107, 22);
            this.chkIgnoreCase.TabIndex = 47;
            this.chkIgnoreCase.Text = "Ignore Case";
            this.chkIgnoreCase.UseVisualStyleBackColor = true;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(329, 49);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(111, 18);
            this.label7.TabIndex = 33;
            this.label7.Text = "Files to Search:";
            // 
            // rbSearchWithinFile
            // 
            this.rbSearchWithinFile.AutoSize = true;
            this.rbSearchWithinFile.Checked = true;
            this.rbSearchWithinFile.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbSearchWithinFile.Location = new System.Drawing.Point(332, 10);
            this.rbSearchWithinFile.Name = "rbSearchWithinFile";
            this.rbSearchWithinFile.Size = new System.Drawing.Size(141, 22);
            this.rbSearchWithinFile.TabIndex = 34;
            this.rbSearchWithinFile.TabStop = true;
            this.rbSearchWithinFile.Text = "Search within File";
            this.rbSearchWithinFile.UseVisualStyleBackColor = true;
            // 
            // rbSearchInFileName
            // 
            this.rbSearchInFileName.AutoSize = true;
            this.rbSearchInFileName.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbSearchInFileName.Location = new System.Drawing.Point(13, 10);
            this.rbSearchInFileName.Name = "rbSearchInFileName";
            this.rbSearchInFileName.Size = new System.Drawing.Size(159, 22);
            this.rbSearchInFileName.TabIndex = 35;
            this.rbSearchInFileName.Text = "Search in File Name";
            this.rbSearchInFileName.UseVisualStyleBackColor = true;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(213, 48);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(21, 18);
            this.label9.TabIndex = 42;
            this.label9.Text = "to";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Black;
            this.label10.Location = new System.Drawing.Point(9, 90);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(308, 13);
            this.label10.TabIndex = 43;
            this.label10.Text = "!!! To search in a single folder pass folder number in both ranges";
            // 
            // txtFolderRangeStart
            // 
            this.txtFolderRangeStart.Enabled = false;
            this.txtFolderRangeStart.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFolderRangeStart.Increment = new decimal(new int[] {
            50,
            0,
            0,
            0});
            this.txtFolderRangeStart.Location = new System.Drawing.Point(136, 48);
            this.txtFolderRangeStart.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.txtFolderRangeStart.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.txtFolderRangeStart.Name = "txtFolderRangeStart";
            this.txtFolderRangeStart.Size = new System.Drawing.Size(74, 22);
            this.txtFolderRangeStart.TabIndex = 44;
            this.txtFolderRangeStart.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // txtFolderRangeEnd
            // 
            this.txtFolderRangeEnd.Enabled = false;
            this.txtFolderRangeEnd.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFolderRangeEnd.Increment = new decimal(new int[] {
            50,
            0,
            0,
            0});
            this.txtFolderRangeEnd.Location = new System.Drawing.Point(240, 49);
            this.txtFolderRangeEnd.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.txtFolderRangeEnd.Name = "txtFolderRangeEnd";
            this.txtFolderRangeEnd.Size = new System.Drawing.Size(74, 22);
            this.txtFolderRangeEnd.TabIndex = 45;
            // 
            // chkFolderRange
            // 
            this.chkFolderRange.AutoSize = true;
            this.chkFolderRange.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkFolderRange.Location = new System.Drawing.Point(11, 48);
            this.chkFolderRange.Name = "chkFolderRange";
            this.chkFolderRange.Size = new System.Drawing.Size(120, 22);
            this.chkFolderRange.TabIndex = 46;
            this.chkFolderRange.Text = "Folder Range:";
            this.chkFolderRange.UseVisualStyleBackColor = true;
            this.chkFolderRange.CheckedChanged += new System.EventHandler(this.chkFolderRange_CheckedChanged);
            // 
            // panelInput
            // 
            this.panelInput.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelInput.Controls.Add(this.label8);
            this.panelInput.Controls.Add(this.txtExtension);
            this.panelInput.Controls.Add(this.chkFolderRange);
            this.panelInput.Controls.Add(this.txtFolderRangeEnd);
            this.panelInput.Controls.Add(this.txtFolderRangeStart);
            this.panelInput.Controls.Add(this.label10);
            this.panelInput.Controls.Add(this.label9);
            this.panelInput.Controls.Add(this.rbSearchInFileName);
            this.panelInput.Controls.Add(this.rbSearchWithinFile);
            this.panelInput.Controls.Add(this.label7);
            this.panelInput.Location = new System.Drawing.Point(30, 124);
            this.panelInput.Name = "panelInput";
            this.panelInput.Size = new System.Drawing.Size(565, 142);
            this.panelInput.TabIndex = 50;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Black;
            this.label8.Location = new System.Drawing.Point(10, 113);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(442, 13);
            this.label8.TabIndex = 48;
            this.label8.Text = "!!! Permissible pattern of \"Files to Search\" are TXT, IDX5 etc. To search all typ" +
    "e of files use *";
            // 
            // txtExtension
            // 
            this.txtExtension.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtExtension.Location = new System.Drawing.Point(446, 49);
            this.txtExtension.Name = "txtExtension";
            this.txtExtension.Size = new System.Drawing.Size(102, 22);
            this.txtExtension.TabIndex = 47;
            this.txtExtension.Text = "*";
            // 
            // searchKingMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(625, 600);
            this.Controls.Add(this.chkIgnoreCase);
            this.Controls.Add(this.panelProgress);
            this.Controls.Add(this.panelInput);
            this.Controls.Add(this.txtCollatePath);
            this.Controls.Add(this.cbCollateFiles);
            this.Controls.Add(this.cbCreateLog);
            this.Controls.Add(this.txtLogPath);
            this.Controls.Add(this.treeList);
            this.Controls.Add(this.lblHelp);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.cmdClose);
            this.Controls.Add(this.cmdClear);
            this.Controls.Add(this.cmdBrowse);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtSearchText);
            this.Controls.Add(this.cmdSearch);
            this.Controls.Add(this.txtSearchPath);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "searchKingMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "SearchKing v5.0";
            this.panelProgress.ResumeLayout(false);
            this.panelProgress.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtFolderRangeStart)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtFolderRangeEnd)).EndInit();
            this.panelInput.ResumeLayout(false);
            this.panelInput.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtSearchPath;
        private System.Windows.Forms.Button cmdSearch;
        private System.Windows.Forms.TextBox txtSearchText;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button cmdBrowse;
        private System.Windows.Forms.Button cmdClear;
        private System.Windows.Forms.Button cmdClose;
        private System.Windows.Forms.FolderBrowserDialog dlgFolder;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.LinkLabel lblHelp;
        private System.Windows.Forms.TreeView treeList;
        private System.Windows.Forms.TextBox txtLogPath;
        private System.Windows.Forms.CheckBox cbCreateLog;
        private System.Windows.Forms.CheckBox cbCollateFiles;
        private System.Windows.Forms.TextBox txtCollatePath;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panelProgress;
        private System.Windows.Forms.Label lblProgressFinished;
        private System.Windows.Forms.Label lblProgressResult;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.CheckBox chkIgnoreCase;
        private System.Windows.Forms.Label lblProgressFinishedDir;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.RadioButton rbSearchWithinFile;
        private System.Windows.Forms.RadioButton rbSearchInFileName;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.NumericUpDown txtFolderRangeStart;
        private System.Windows.Forms.NumericUpDown txtFolderRangeEnd;
        private System.Windows.Forms.CheckBox chkFolderRange;
        private System.Windows.Forms.Panel panelInput;
        private System.Windows.Forms.TextBox txtExtension;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button cmdOpenLogFolder;
    }
}

